<?php

return [
    'name' => 'Admin',
];
